<?php
declare(strict_types=1);
namespace bridge\Entity;

use pocketmine\entity\Human;

class MainEntity extends Human
{
	public function getName(): string
	{
		return '';
	}
}
?>